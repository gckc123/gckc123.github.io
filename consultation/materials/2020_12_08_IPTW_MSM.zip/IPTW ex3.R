## Load libraries

library(tidyverse)
library(ggplot2)
library(forcats)
library(lubridate)
initialise_seed <- runif(1)

## Load data

setwd("C:\\Users\\gckc1\\Documents") 
library(tidyverse)
currentDataset <- read_csv("iptw_example_with_missing.csv")

## Multiple imputation and IPTW

library(ipw)

"Impute missing data"
library(mice)
library(mitools)


formulas <- make.formulas(currentDataset)

formulas$illicit =illicit ~ can_1 + failed_0 + peer_can_0 + antisocial_0 + can_0 + family_drug_use + sex + can_2 + failed_1 + peer_can_1 + antisocial_1 + can_3 + failed_2 + peer_can_2 + antisocial_2
formulas$can_1 =can_1 ~ illicit + failed_0 + peer_can_0 + antisocial_0 + can_0 + family_drug_use + sex + can_2 + failed_1 + peer_can_1 + antisocial_1 + can_3 + failed_2 + peer_can_2 + antisocial_2
formulas$failed_0 =failed_0 ~ illicit + can_1 + peer_can_0 + antisocial_0 + can_0 + family_drug_use + sex + can_2 + failed_1 + peer_can_1 + antisocial_1 + can_3 + failed_2 + peer_can_2 + antisocial_2
formulas$peer_can_0 =peer_can_0 ~ illicit + can_1 + failed_0 + antisocial_0 + can_0 + family_drug_use + sex + can_2 + failed_1 + peer_can_1 + antisocial_1 + can_3 + failed_2 + peer_can_2 + antisocial_2
formulas$antisocial_0 =antisocial_0 ~ illicit + can_1 + failed_0 + peer_can_0 + can_0 + family_drug_use + sex + can_2 + failed_1 + peer_can_1 + antisocial_1 + can_3 + failed_2 + peer_can_2 + antisocial_2
formulas$can_0 =can_0 ~ illicit + can_1 + failed_0 + peer_can_0 + antisocial_0 + family_drug_use + sex + can_2 + failed_1 + peer_can_1 + antisocial_1 + can_3 + failed_2 + peer_can_2 + antisocial_2
formulas$family_drug_use =family_drug_use ~ illicit + can_1 + failed_0 + peer_can_0 + antisocial_0 + can_0 + sex + can_2 + failed_1 + peer_can_1 + antisocial_1 + can_3 + failed_2 + peer_can_2 + antisocial_2
formulas$sex =sex ~ illicit + can_1 + failed_0 + peer_can_0 + antisocial_0 + can_0 + family_drug_use + can_2 + failed_1 + peer_can_1 + antisocial_1 + can_3 + failed_2 + peer_can_2 + antisocial_2
formulas$can_2 =can_2 ~ illicit + can_1 + failed_0 + peer_can_0 + antisocial_0 + can_0 + family_drug_use + sex + failed_1 + peer_can_1 + antisocial_1 + can_3 + failed_2 + peer_can_2 + antisocial_2
formulas$failed_1 =failed_1 ~ illicit + can_1 + failed_0 + peer_can_0 + antisocial_0 + can_0 + family_drug_use + sex + can_2 + peer_can_1 + antisocial_1 + can_3 + failed_2 + peer_can_2 + antisocial_2
formulas$peer_can_1 =peer_can_1 ~ illicit + can_1 + failed_0 + peer_can_0 + antisocial_0 + can_0 + family_drug_use + sex + can_2 + failed_1 + antisocial_1 + can_3 + failed_2 + peer_can_2 + antisocial_2
formulas$antisocial_1 =antisocial_1 ~ illicit + can_1 + failed_0 + peer_can_0 + antisocial_0 + can_0 + family_drug_use + sex + can_2 + failed_1 + peer_can_1 + can_3 + failed_2 + peer_can_2 + antisocial_2
formulas$can_3 =can_3 ~ illicit + can_1 + failed_0 + peer_can_0 + antisocial_0 + can_0 + family_drug_use + sex + can_2 + failed_1 + peer_can_1 + antisocial_1 + failed_2 + peer_can_2 + antisocial_2
formulas$failed_2 =failed_2 ~ illicit + can_1 + failed_0 + peer_can_0 + antisocial_0 + can_0 + family_drug_use + sex + can_2 + failed_1 + peer_can_1 + antisocial_1 + can_3 + peer_can_2 + antisocial_2
formulas$peer_can_2 =peer_can_2 ~ illicit + can_1 + failed_0 + peer_can_0 + antisocial_0 + can_0 + family_drug_use + sex + can_2 + failed_1 + peer_can_1 + antisocial_1 + can_3 + failed_2 + antisocial_2
formulas$antisocial_2 =antisocial_2 ~ illicit + can_1 + failed_0 + peer_can_0 + antisocial_0 + can_0 + family_drug_use + sex + can_2 + failed_1 + peer_can_1 + antisocial_1 + can_3 + failed_2 + peer_can_2

meth <- make.method(currentDataset)
meth["failed_3"] <- ""
meth["family_alc_supp_0"] <- ""
meth["family_alc_supp_1"] <- ""
meth["family_alc_supp_2"] <- ""
meth["family_alc_supp_3"] <- ""
meth["peer_can_3"] <- ""
meth["peer_alc_0"] <- ""
meth["peer_alc_1"] <- ""
meth["peer_alc_2"] <- ""
meth["peer_alc_3"] <- ""
meth["antisocial_3"] <- ""
meth["alc_0"] <- ""
meth["alc_1"] <- ""
meth["alc_2"] <- ""
meth["alc_3"] <- ""
meth["distress"] <- ""
meth["alc_dep"] <- ""

imputedDataset <- parlmice(currentDataset,
                           method = meth,
                           formulas = formulas,
                           m = 20,
                           n.core = 1, 
                           n.imp.core = 20)

plot(imputedDataset)
currentDataset <- complete(imputedDataset, action = "long", include = TRUE)

"Calculate IPTW"

split_imp <- currentDataset$.imp
mi_dataList <- split(currentDataset, split_imp)

for(i in 2:length(mi_dataList)) {
  weight <- ipwpoint(exposure = can_1, family = "binomial", link = "logit",
                     numerator =~ 1,
                     denominator =~ failed_0+peer_can_0+antisocial_0+can_0+family_drug_use+sex,
                     trunc = 0.01, data = as.data.frame(mi_dataList[[i]]))
  
  mi_dataList[[i]]$.ipw0 = weight$weights.trunc
  
  weight <- ipwpoint(exposure = can_2, family = "binomial", link = "logit",
                     numerator =~ can_1,
                     denominator =~ can_1+failed_0+peer_can_0+antisocial_0+can_0+family_drug_use+sex+failed_1+peer_can_1+antisocial_1,
                     trunc = 0.01, data = as.data.frame(mi_dataList[[i]]))
  
  mi_dataList[[i]]$.ipw1 = weight$weights.trunc
  
  weight <- ipwpoint(exposure = can_3, family = "binomial", link = "logit",
                     numerator =~ can_1+can_2,
                     denominator =~ can_1+can_2+failed_0+peer_can_0+antisocial_0+can_0+family_drug_use+sex+failed_1+peer_can_1+antisocial_1+failed_2+peer_can_2+antisocial_2,
                     trunc = 0.01, data = as.data.frame(mi_dataList[[i]]))
  
  mi_dataList[[i]]$.ipw2 = weight$weights.trunc
  
  mi_dataList[[i]]$.final_weight <- mi_dataList[[i]]$.ipw0*mi_dataList[[i]]$.ipw1*mi_dataList[[i]]$.ipw2
  
}

mi_dataList[[1]]$.ipw0 <- NA
mi_dataList[[1]]$.ipw1 <- NA
mi_dataList[[1]]$.ipw2 <- NA
mi_dataList[[1]]$.final_weight <- NA

currentDataset <- unsplit(mi_dataList, split_imp)


"Chan, G. and StatsNotebook Team (2020). StatsNotebook. (Version 0.1.0) [Computer Software]. Retrieved from https://www.statsnotebook.io"
"R Core Team (2020). The R Project for Statistical Computing. [Computer software]. Retrieved from https://r-project.org"
"van der Wal, W. M. and R. B. Geskus (2011). ipw: an R package for inverse probability weighting. J Stat Softw 43(13): 1-23."

## Compute cumulative explosure

currentDataset$cumulative_exposure <- currentDataset$can_1+currentDataset$can_2+currentDataset$can_3

## Outcome model

library(mice)
library(mitools)

library(survey)

"Weighted linear regression"

mi_dataList <- currentDataset[currentDataset$.imp != 0,]
mi_dataList <- split(mi_dataList, mi_dataList$.imp)
mi_dataList <- imputationList(mi_dataList)
clus <- svydesign(id =~ 1, weights =~ .final_weight, data = mi_dataList)
res <- with(clus, svyglm(illicit ~ cumulative_exposure, family = binomial))
summary(MIcombine(res), alpha = 0.05,
        logeffect = TRUE)

res1 <- res[[1]]
car::infIndexPlot(res1)


"Chan, G. and StatsNotebook Team (2020). StatsNotebook. (Version 0.1.0) [Computer Software]. Retrieved from https://www.statsnotebook.io"
"R Core Team (2020). The R Project for Statistical Computing. [Computer software]. Retrieved from https://r-project.org"

