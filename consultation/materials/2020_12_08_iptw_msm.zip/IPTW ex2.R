## Load Libraries

library(tidyverse)
library(ggplot2)
library(forcats)
library(lubridate)
initialise_seed <- runif(1)

## Load data file
## Change the directory in setwd to your file localtion

setwd("C:\\Users\\gckc1\\Documents") 
library(tidyverse)
currentDataset <- read_csv("iptw_example.csv")

## Calculate IPTW

library(ipw)

"Calculate IPTW"

weight <- ipwpoint(exposure = can_1, family = "binomial", link = "logit",
                   numerator =~ 1,
                   denominator =~ failed_0+peer_can_0+antisocial_0+can_0+family_drug_use+sex,
                   trunc = 0.01, data = as.data.frame(currentDataset))
currentDataset$.ipw0 = weight$weights.trunc

weight <- ipwpoint(exposure = can_2, family = "binomial", link = "logit",
                   numerator =~ can_1,
                   denominator =~ can_1+failed_0+peer_can_0+antisocial_0+can_0+family_drug_use+sex+failed_1+peer_can_1+antisocial_1,
                   trunc = 0.01, data = as.data.frame(currentDataset))
currentDataset$.ipw1 = weight$weights.trunc

weight <- ipwpoint(exposure = can_3, family = "binomial", link = "logit",
                   numerator =~ can_1+can_2,
                   denominator =~ can_1+can_2+failed_0+peer_can_0+antisocial_0+can_0+family_drug_use+sex+failed_1+peer_can_1+antisocial_1+failed_2+peer_can_2+peer_alc_2,
                   trunc = 0.01, data = as.data.frame(currentDataset))
currentDataset$.ipw2 = weight$weights.trunc

currentDataset$.final_weight <- currentDataset$.ipw0*currentDataset$.ipw1*currentDataset$.ipw2


"Chan, G. and StatsNotebook Team (2020). StatsNotebook. (Version 0.1.0) [Computer Software]. Retrieved from https://www.statsnotebook.io"
"R Core Team (2020). The R Project for Statistical Computing. [Computer software]. Retrieved from https://r-project.org"
"van der Wal, W. M. and R. B. Geskus (2011). ipw: an R package for inverse probability weighting. J Stat Softw 43(13): 1-23."

## Compute cumulative exposure

currentDataset$cumulative_exposure <- currentDataset$can_1+currentDataset$can_2+currentDataset$can_3

## Outcome model

"Weighted logistic regression"

library(survey)

clus <- svydesign(id =~ 1, weights =~ .final_weight, data = currentDataset)
res <- svyglm(illicit ~ cumulative_exposure, design = clus,family = binomial)
summary(res)
"Model coefficients and confidence intervals"
cbind(coef(res), confint(res, level = 0.95))

"Odds ratios and confidence intervals"
exp(cbind(OR = coef(res), confint(res, level = 0.95)))


car::infIndexPlot(res)


"Chan, G. and StatsNotebook Team (2020). StatsNotebook. (Version 0.1.0) [Computer Software]. Retrieved from https://www.statsnotebook.io"
"R Core Team (2020). The R Project for Statistical Computing. [Computer software]. Retrieved from https://r-project.org"
